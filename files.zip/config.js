// Configura aquí tu proyecto (Supabase > Project Settings > API). Solo clave anon/public, NUNCA service_role.
window.APP_CONFIG = {
  SUPABASE_URL: "https://TU-PROYECTO.supabase.co",
  SUPABASE_ANON_KEY: "TU_ANON_KEY"
};
